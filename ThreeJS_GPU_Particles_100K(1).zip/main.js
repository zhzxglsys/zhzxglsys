
import * as THREE from 'https://unpkg.com/three@0.179.1/build/three.module.js';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, innerWidth/innerHeight, 0.1, 1000);
camera.position.z = 120;

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth, innerHeight);
document.body.appendChild(renderer.domElement);

const COUNT = 100000;

const positions = new Float32Array(COUNT * 3);
const scales = new Float32Array(COUNT);

for(let i=0;i<COUNT;i++){
  positions[i*3]   = (Math.random()-0.5)*200;
  positions[i*3+1] = (Math.random()-0.5)*200;
  positions[i*3+2] = (Math.random()-0.5)*200;
  scales[i] = Math.random();
}

const geometry = new THREE.BufferGeometry();
geometry.setAttribute('position', new THREE.BufferAttribute(positions,3));
geometry.setAttribute('scale', new THREE.BufferAttribute(scales,1));

const material = new THREE.ShaderMaterial({
transparent:true,
depthWrite:false,
blending:THREE.AdditiveBlending,
uniforms:{ time:{value:0} },

vertexShader:`
attribute float scale;
uniform float time;

void main(){
 vec3 p = position;

 p.x += sin(time + p.y*0.05)*2.0;
 p.y += cos(time + p.z*0.05)*2.0;

 vec4 mvPosition = modelViewMatrix * vec4(p,1.0);

 gl_PointSize = (2.0 + scale*4.0) * (300.0 / -mvPosition.z);
 gl_Position = projectionMatrix * mvPosition;
}`,
fragmentShader:`
void main(){
 float d = length(gl_PointCoord - vec2(0.5));
 if(d > 0.5) discard;

 float a = 1.0 - smoothstep(0.0,0.5,d);
 gl_FragColor = vec4(0.2,0.8,1.0,a);
}`
});

const particles = new THREE.Points(geometry, material);
scene.add(particles);

addEventListener('mousemove', e=>{
 const x = (e.clientX/innerWidth - 0.5) * 2.0;
 const y = (e.clientY/innerHeight - 0.5) * 2.0;
 particles.rotation.y = x * 0.8;
 particles.rotation.x = y * 0.8;
});

addEventListener('resize', ()=>{
 camera.aspect = innerWidth/innerHeight;
 camera.updateProjectionMatrix();
 renderer.setSize(innerWidth, innerHeight);
});

function animate(t){
 requestAnimationFrame(animate);
 material.uniforms.time.value = t * 0.001;
 particles.rotation.z += 0.0008;
 renderer.render(scene,camera);
}
animate();
